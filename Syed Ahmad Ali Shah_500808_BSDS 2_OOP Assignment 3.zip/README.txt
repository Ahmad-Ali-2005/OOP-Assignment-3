Syed Ahmad Ali Shah - 500808 - BSDS 2
OOP Assignment 3 - Health Management System

In order to run project from github follow these steps:
1. Locate zip file in repo.
2. Download and extract zip file.
3. Follow steps listed in zip file section below.


In order to run project from zip file follow these steps:
1. Extract zip file.
2. Locate src folder.
3. Open src folder in any IDE and run code after making sure that main class name, package name etc. are all in order (main function name and package name should match name of project).

NOTE: Both GitHub repo and zip file also includes word document with attached screenshots of testing of classes.