package main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


import usermanagement.User;
import usermanagement.Patient;
import usermanagement.Doctor;
import usermanagement.Administrator;
import healthdata.VitalSigns;
import appointment.Appointment;
import appointment.AppointmentManager;
import chatvideoconsultation.ChatClient;
import chatvideoconsultation.ChatServer;
import chatvideoconsultation.VideoCall;
import chatvideoconsultation.Message;
import doctorpateint.FeedBack;
import doctorpateint.Prescription;
import healthdata.VItalDataBase;
import emergencyalert.AlertFactory;
import emergencyalert.AlertService;
import emergencyalert.EmergencyAlert;
import emergencyalert.NotificationService;
import emergencyalert.PanicButton;
import java.util.HashMap;
import java.util.Map;

import notificationsandremainders.EmailNotification;
import notificationsandremainders.SMSNotification;
import notificationsandremainders.Notifiable;
import notificationsandremainders.RemainderService;


public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    // System components
    private static Administrator admin;
    private static AppointmentManager appointmentManager;
    private static VItalDataBase vitalsDatabase;
    // Add Emergency Alert components with improved structure
    private static EmergencyAlert emergencyAlert;
    private static AlertService alertService;
    private static PanicButton panicButton;
    // Add Chat Server and Video Call components
    private static ChatServer chatServer;
    private static VideoCall videoCallService;
     // Current logged in user
    private static User currentUser = null;
    private static ChatClient chatClient = null;
    // Notification & Reminder System
    private static RemainderService reminderService;
    private static EmailNotification emailNotification;
    private static SMSNotification smsNotification;

    public static void main(String[] args) {
        // Initialize system
        initialize();
        
        boolean running = true;
        while (running) {
            if (currentUser == null) {
                displayLoginMenu();
            } else {
                if (currentUser.getRole().equals("Administrator")) {
                    displayAdminMenu();
                } else if (currentUser.getRole().equals("Doctor")) {
                    displayDoctorMenu();
                } else if (currentUser.getRole().equals("Patient")) {
                    displayPatientMenu();
                }
            }
        }
    }
    
    private static void initialize() {
        System.out.println("Initializing Hospital Management System...");
        
        // Create primary administrator
        System.out.println("Setting up administrator account:");
        System.out.print("Enter Admin ID: ");
        String adminId = scanner.nextLine();
        System.out.print("Enter Admin Name: ");
        String adminName = scanner.nextLine();
        System.out.print("Enter Admin Contact: ");
        String adminContact = scanner.nextLine();
        
        admin = new Administrator(adminId, adminName, adminContact);
        
        // Initialize system components
        appointmentManager = new AppointmentManager();
        vitalsDatabase = new VItalDataBase();
        
        // Initialize Emergency Alert System components using the factory pattern
        alertService = new NotificationService();
        emergencyAlert = AlertFactory.createEmergencyAlert();
        panicButton = AlertFactory.createPanicButton();
        
        // Initialize Chat and Video components
        chatServer = ChatServer.getInstance();
        videoCallService = new VideoCall();
        reminderService = new RemainderService();
        
        // Initialize Notification and Reminder System
//       initializeNotificationSystem();
//        
//        System.out.println("System initialized successfully!");
    }
    
// Initialize the notification and reminder system
private static void initializeNotificationSystem() {
    System.out.println("Initializing Notification and Reminder System...");
    
    // Initialize notification channels
    System.out.print("Enter system email address for notifications: ");
    String systemEmail = scanner.nextLine();
    emailNotification = new EmailNotification(systemEmail);
    
    System.out.print("Enter system phone number for SMS notifications: ");
    String systemPhone = scanner.nextLine();
    smsNotification = new SMSNotification(systemPhone);
    
    // Initialize reminder service
    reminderService = new RemainderService();
    
    // Add notification channels to reminder service
    reminderService.addNotificationChannel(emailNotification);
    reminderService.addNotificationChannel(smsNotification);     
    
    System.out.println("Notification and Reminder System initialized successfully!");
}

    private static void displayLoginMenu() {
        System.out.println("\n===== HOSPITAL MANAGEMENT SYSTEM =====");
        System.out.println("1. Login as Administrator");
        System.out.println("2. Login as Doctor");
        System.out.println("3. Login as Patient");
        System.out.println("0. Exit");
        System.out.print("Select an option: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                loginAsAdmin();
                break;
            case 2:
                loginAsDoctor();
                break;
            case 3:
                loginAsPatient();
                break;
            case 0:
                System.out.println("Thank you for using the Hospital Management System. Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
    
    // ===== ADMIN FUNCTIONS =====
    
    private static void loginAsAdmin() {
        System.out.print("Enter admin ID: ");
        String adminId = scanner.nextLine();
        
        if (adminId.equals(admin.getUserId())) {
            currentUser = admin;
            System.out.println("Welcome, " + admin.getName() + "!");
            // Initialize chat client for admin
            chatClient = new ChatClient(admin.getUserId());
        } else {
            System.out.println("Invalid administrator ID.");
        }
    }
    
    private static void displayAdminMenu() {
        System.out.println("\n===== ADMINISTRATOR MENU =====");
        System.out.println("1. View All Users");
        System.out.println("2. Add New Doctor");
        System.out.println("3. Add New Patient");
        System.out.println("4. Remove User");
        System.out.println("5. View System Summary");
        System.out.println("6. Configure Emergency Alert Thresholds");
        System.out.println("7. Manage Chat Server");
        System.out.println("8. Logout");
        System.out.print("Select an option: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                viewAllUsers();
                break;
            case 2:
                addNewDoctor();
                break;
            case 3:
                addNewPatient();
                break;
            case 4:
                removeUser();
                break;
            case 5:
                displaySystemSummary();
                break;
            case 6:
                configureEmergencyAlertThresholds();
                break;
            case 7:
                manageChatServer();
                break;
            case 8:
                logout();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
    
    private static void viewAllUsers() {
        System.out.println("\n===== ALL USERS =====");
        if (admin.getUsers().isEmpty()) {
            System.out.println("No users in the system yet.");
        } else {
            for (User user : admin.getUsers().values()) {
                System.out.println("[" + user.getRole() + "] " + user.getUserId() + ": " + user.getName() + " - " + user.getContactInfo());
            }
        }
    }
    
    private static void addNewDoctor() {
        System.out.print("Enter doctor ID: ");
        String doctorId = scanner.nextLine();
        
        // Check if ID already exists
        if (admin.getUser(doctorId) != null) {
            System.out.println("User ID already exists. Please use a different ID.");
            return;
        }
        
        System.out.print("Enter doctor name: ");
        String doctorName = scanner.nextLine();
        
        System.out.print("Enter doctor contact info: ");
        String contactInfo = scanner.nextLine();
        
        Doctor newDoctor = new Doctor(doctorId, doctorName, contactInfo);
        admin.addUser(newDoctor);
        
        // Register doctor with chat server
        chatServer.registerUser(newDoctor);
        
        System.out.println("Doctor added successfully!");
    }
    
    private static void addNewPatient() {
        System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();
        
        // Check if ID already exists
        if (admin.getUser(patientId) != null) {
            System.out.println("User ID already exists. Please use a different ID.");
            return;
        }
        
        System.out.print("Enter patient name: ");
        String patientName = scanner.nextLine();
        
        System.out.print("Enter patient contact info: ");
        String contactInfo = scanner.nextLine();
        
        Patient newPatient = new Patient(patientId, patientName, contactInfo);
        admin.addUser(newPatient);
        
        // Register patient with chat server
        chatServer.registerUser(newPatient);
        
        System.out.println("Patient added successfully!");
        
        // Optional: Assign patient to doctor
        System.out.print("Would you like to assign this patient to a doctor now? (y/n): ");
        String choice = scanner.nextLine();
        
        if (choice.equalsIgnoreCase("y")) {
            assignPatientToDoctor(newPatient);
        }
    }
    
   private static void assignPatientToDoctor(Patient patient) {
    System.out.println("\n===== AVAILABLE DOCTORS =====");
    boolean doctorsAvailable = false;

    // Loop through all users and check if they are doctors
    for (User user : admin.getUsers().values()) {
        if (user instanceof Doctor) {
            System.out.println("- " + user.getUserId() + ": " + user.getName());
            doctorsAvailable = true;
        }
    }

    if (!doctorsAvailable) {
        System.out.println("No doctors available in the system. Please add doctors first.");
        return;
    }

    System.out.print("Enter doctor ID to assign patient: ");
    String doctorId = scanner.nextLine();

    // Retrieve the doctor by ID
    User user = admin.getUser(doctorId);
    if (user != null && user instanceof Doctor) {
        Doctor doctor = (Doctor) user;

        // Add the patient to the doctor's list of patients
        doctor.addPatient(patient);

        // Ensure the patient is also aware of the doctor (bidirectional relationship)
        patient.assignDoctor(doctor);

        System.out.println("Patient " + patient.getName() + " assigned to Dr. " + doctor.getName() + " successfully!");
    } else {
        System.out.println("Doctor not found or invalid ID.");
    }
}

    
    private static void removeUser() {
        System.out.print("Enter user ID to remove: ");
        String userId = scanner.nextLine();
        
        User user = admin.getUser(userId);
        if (user != null) {
            admin.removeUser(userId);
            System.out.println("User " + userId + " removed successfully.");
        } else {
            System.out.println("User not found.");
        }
    }
    
    private static void displaySystemSummary() {
        System.out.println("\n===== SYSTEM SUMMARY =====");
        System.out.println("Administrator: " + admin.getName() + " (ID: " + admin.getUserId() + ")");
        
        int doctorCount = 0;
        int patientCount = 0;
        
        for (User user : admin.getUsers().values()) {
            if (user instanceof Doctor) {
                doctorCount++;
            } else if (user instanceof Patient) {
                patientCount++;
            }
        }
        
        System.out.println("Total Doctors: " + doctorCount);
        System.out.println("Total Patients: " + patientCount);
        System.out.println("Total Appointments: " + appointmentManager.getTotalAppointments());
        System.out.println("Total Vital Sign Records: " + vitalsDatabase.getTotalRecords());
    }
    
    // Updated Admin function to configure emergency alert thresholds with improved OOP
    private static void configureEmergencyAlertThresholds() {
        System.out.println("\n===== CONFIGURE EMERGENCY ALERT THRESHOLDS =====");
        System.out.println("Current thresholds:");
        System.out.println("1. Heart Rate (Max): " + emergencyAlert.getThresholds().get("heartRateMax"));
        System.out.println("2. Heart Rate (Min): " + emergencyAlert.getThresholds().get("heartRateMin"));
        System.out.println("3. Oxygen Level (Min): " + emergencyAlert.getThresholds().get("oxygenLevelMin"));
        System.out.println("4. Blood Pressure Systolic (Max): " + emergencyAlert.getThresholds().get("bloodPressureSystolicMax"));
        System.out.println("5. Blood Pressure Diastolic (Max): " + emergencyAlert.getThresholds().get("bloodPressureDiastolicMax"));
        System.out.println("6. Temperature (Max): " + emergencyAlert.getThresholds().get("temperatureMax"));
        System.out.println("7. Temperature (Min): " + emergencyAlert.getThresholds().get("temperatureMin"));
        System.out.println("8. Return to Admin Menu");
        System.out.print("Select threshold to modify: ");
        
        int choice = getIntInput();
        String thresholdKey = "";
        
        switch (choice) {
            case 1:
                thresholdKey = "heartRateMax";
                break;
            case 2:
                thresholdKey = "heartRateMin";
                break;
            case 3:
                thresholdKey = "oxygenLevelMin";
                break;
            case 4:
                thresholdKey = "bloodPressureSystolicMax";
                break;
            case 5:
                thresholdKey = "bloodPressureDiastolicMax";
                break;
            case 6:
                thresholdKey = "temperatureMax";
                break;
            case 7:
                thresholdKey = "temperatureMin";
                break;
            case 8:
                return;
            default:
                System.out.println("Invalid choice. Returning to Admin Menu.");
                return;
        }
        
        System.out.print("Enter new value for " + thresholdKey + ": ");
        double newValue = getDoubleInput();
        // Updated to use the new method name
        emergencyAlert.setThreshold(thresholdKey, newValue);
        System.out.println("Threshold updated successfully!");
    }
    
    // New Admin function to manage the chat server
    private static void manageChatServer() {
        System.out.println("\n===== CHAT SERVER MANAGEMENT =====");
        System.out.println("1. View Doctor-Patient Relationships");
        System.out.println("2. Validate Doctor-Patient Relationship");
        System.out.println("3. Return to Admin Menu");
        System.out.print("Select an option: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                viewDoctorPatientRelationships();
                break;
            case 2:
                validateDoctorPatientRelationship();
                break;
            case 3:
                return;
            default:
                System.out.println("Invalid choice. Returning to Admin Menu.");
        }
    }
    
    private static void viewDoctorPatientRelationships() {
        System.out.println("\n===== DOCTOR-PATIENT RELATIONSHIPS =====");
        boolean relationshipsExist = false;
        
        for (User user : admin.getUsers().values()) {
            if (user instanceof Doctor) {
                Doctor doctor = (Doctor) user;
                System.out.println("Doctor: " + doctor.getName() + " (ID: " + doctor.getUserId() + ")");
                
                if (doctor.getPatients().isEmpty()) {
                    System.out.println("  - No patients assigned");
                } else {
                    for (Patient patient : doctor.getPatients()) {
                        System.out.println("  - Patient: " + patient.getName() + " (ID: " + patient.getUserId() + ")");
                        relationshipsExist = true;
                    }
                }
                System.out.println();
            }
        }
        
        if (!relationshipsExist) {
            System.out.println("No doctor-patient relationships established yet.");
        }
    }
    
    private static void validateDoctorPatientRelationship() {
        System.out.print("Enter doctor ID: ");
        String doctorId = scanner.nextLine();
        
        System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();
        
        boolean isValid = chatServer.validateDoctorPatientRelationship(doctorId, patientId);
        
        if (isValid) {
            System.out.println("VALID: The doctor-patient relationship exists.");
        } else {
            System.out.println("INVALID: The doctor-patient relationship does not exist.");
        }
    }
    
    // ===== DOCTOR FUNCTIONS =====
    
    private static void loginAsDoctor() {
        System.out.print("Enter doctor ID: ");
        String doctorId = scanner.nextLine();
        
        User user = admin.getUser(doctorId);
        if (user != null && user.getRole().equals("Doctor")) {
            currentUser = user;
            System.out.println("Welcome, Dr. " + user.getName() + "!");
            // Initialize chat client for doctor
            chatClient = new ChatClient(user.getUserId());
        } else {
            System.out.println("Invalid doctor ID.");
        }
    }
    
    private static void displayDoctorMenu() {
        Doctor doctor = (Doctor) currentUser;
        
        System.out.println("\n===== DOCTOR MENU =====");
        System.out.println("1. View My Patients");
        System.out.println("2. View Patient Data");
        System.out.println("3. View My Appointments");
        System.out.println("4. Provide Feedback to Patient");
        System.out.println("5. Issue Prescription");
        System.out.println("6. Monitor Patient Vital Signs");
        System.out.println("7. Chat with Patient");
        System.out.println("8. Start Video Consultation");
        System.out.println("9. Send Notification to Patient");
        System.out.println("10. Manage Patient Reminders");
        System.out.println("11. Logout");
        System.out.print("Select an option: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                viewDoctorPatients(doctor);
                break;
            case 2:
                viewPatientData(doctor);
                break;
            case 3:
                doctor.viewAllAppointments();
                break;
            case 4:
                provideFeedback(doctor);
                break;
            case 5:
                issuePrescription(doctor);
                break;
            case 6:
                monitorPatientVitalSigns(doctor);
                break;
            case 7:
                chatWithPatient(doctor);
                break;
            case 8:
                startVideoConsultation(doctor);

            case 9:
                sendNotificationToPatient(doctor);
                break;
            case 10:
                managePatientReminders(doctor);
                break;
            case 11:
                logout();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
    private static void viewDoctorPatients(Doctor doctor) {
        System.out.println("\n===== MY PATIENTS =====");
        if (doctor.getPatients().isEmpty()) {
            System.out.println("You have no patients assigned.");
        } else {
            for (Patient patient : doctor.getPatients()) {
                System.out.println("- " + patient.getUserId() + ": " + patient.getName() + " (" + patient.getContactInfo() + ")");
            }
        }
    }
    
    private static void viewPatientData(Doctor doctor) {
        System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();
        
        User user = admin.getUser(patientId);
        if (user != null && user instanceof Patient) {
            Patient patient = (Patient) user;
            
            // Check if this patient is assigned to the doctor
            boolean isAssigned = false;
            for (Patient p : doctor.getPatients()) {
                if (p.getUserId().equals(patient.getUserId())) {
                    isAssigned = true;
                    break;
                }
            }
            
            if (isAssigned) {
                doctor.viewPatientData(patient);
            } else {
                System.out.println("This patient is not currently assigned to you.");
                System.out.print("Would you like to add this patient to your list? (y/n): ");
                String choice = scanner.nextLine();
                if (choice.equalsIgnoreCase("y")) {
                    doctor.addPatient(patient);
                    System.out.println("Patient added to your list.");
                    doctor.viewPatientData(patient);
                }
            }
        } else {
            System.out.println("Patient not found or invalid ID.");
        }
    }
        private static void provideFeedback(Doctor doctor) {
        System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();
        
        User user = admin.getUser(patientId);
        if (user != null && user instanceof Patient) {
            Patient patient = (Patient) user;
            
            // Check if this patient is assigned to the doctor
            boolean isAssigned = false;
            for (Patient p : doctor.getPatients()) {
                if (p.getUserId().equals(patient.getUserId())) {
                    isAssigned = true;
                    break;
                }
            }
            
            if (isAssigned) {
                System.out.print("Enter feedback: ");
                String feedbackText = scanner.nextLine();
                doctor.provideFeedback(patient, feedbackText);
                System.out.println("Feedback provided successfully.");
            } else {
                System.out.println("This patient is not currently assigned to you. You can only provide feedback to your patients.");
            }
        } else {
            System.out.println("Patient not found or invalid ID.");
        }
    }

        private static void issuePrescription(Doctor doctor) {
        System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();
        
        User user = admin.getUser(patientId);
        if (user != null && user instanceof Patient) {
            // Check if this patient is assigned to the doctor
            Patient patient = (Patient) user;
            boolean isAssigned = false;
            for (Patient p : doctor.getPatients()) {
                if (p.getUserId().equals(patient.getUserId())) {
                    isAssigned = true;
                    break;
                }
            }
            
            if (!isAssigned) {
                System.out.println("This patient is not currently assigned to you. You can only issue prescriptions to your patients.");
                return;
            }
            
            System.out.print("Enter medication name: ");
            String medication = scanner.nextLine();
            
            System.out.print("Enter dosage: ");
            String dosage = scanner.nextLine();
            
            System.out.print("Enter schedule (e.g., 'twice daily'): ");
            String schedule = scanner.nextLine();
            
            Prescription prescription = new Prescription(doctor.getUserId(), patientId, medication, dosage, schedule);
            System.out.println("Prescription issued: " + prescription);
        } else {
            System.out.println("Patient not found or invalid ID.");
        }
    }
    
    // Updated Doctor function to monitor patient vital signs with improved OOP
    private static void monitorPatientVitalSigns(Doctor doctor) {
        System.out.println("\n===== MONITOR PATIENT VITAL SIGNS =====");
        if (doctor.getPatients().isEmpty()) {
            System.out.println("You have no patients assigned.");
            return;
        }
        
        System.out.println("Select a patient to monitor:");
        for (int i = 0; i < doctor.getPatients().size(); i++) {
            Patient patient = doctor.getPatients().get(i);
            System.out.println((i+1) + ". " + patient.getName() + " (ID: " + patient.getUserId() + ")");
        }
        
        System.out.print("Enter patient number: ");
        int patientIndex = getIntInput() - 1;
        
        if (patientIndex >= 0 && patientIndex < doctor.getPatients().size()) {
            Patient selectedPatient = doctor.getPatients().get(patientIndex);
            
            if (selectedPatient.getVitalSigns().isEmpty()) {
                System.out.println("No vital signs data available for this patient.");
                return;
            }
            
            System.out.println("\nVital signs for " + selectedPatient.getName() + ":");
            for (VitalSigns vitalSign : selectedPatient.getVitalSigns()) {
                System.out.println("- " + vitalSign);
            }
            
            System.out.println("\nChecking vital signs against thresholds...");
            emergencyAlert.monitorVitalSigns(selectedPatient, doctor);
        } else {
            System.out.println("Invalid selection.");
        }
    }
    
    // New Doctor function to chat with a patient
    private static void chatWithPatient(Doctor doctor) {
        System.out.println("\n===== CHAT WITH PATIENT =====");
        if (doctor.getPatients().isEmpty()) {
            System.out.println("You have no patients assigned.");
            return;
        }
        
        System.out.println("Select a patient to chat with:");
        for (int i = 0; i < doctor.getPatients().size(); i++) {
            Patient patient = doctor.getPatients().get(i);
            System.out.println((i+1) + ". " + patient.getName() + " (ID: " + patient.getUserId() + ")");
        }
        
        System.out.print("Enter patient number: ");
        int patientIndex = getIntInput() - 1;
        
        if (patientIndex >= 0 && patientIndex < doctor.getPatients().size()) {
            Patient selectedPatient = doctor.getPatients().get(patientIndex);
            
            // Check if there is a valid doctor-patient relationship
            if (!chatServer.validateDoctorPatientRelationship(doctor.getUserId(), selectedPatient.getUserId())) {
                System.out.println("Error: No valid doctor-patient relationship found.");
                return;
            }
            
            System.out.println("\n===== CHAT SESSION WITH " + selectedPatient.getName() + " =====");
            chatClient.displayConversation(selectedPatient.getUserId());
            
            boolean chatting = true;
            while (chatting) {
                System.out.println("\n1. Send message");
                System.out.println("2. Refresh conversation");
                System.out.println("3. End chat session");
                System.out.print("Select an option: ");
                
                int choice = getIntInput();
                
                switch (choice) {
                    case 1:
                        System.out.print("Enter your message: ");
                        String message = scanner.nextLine();
                        chatClient.sendMessage(selectedPatient.getUserId(), message);
                        chatClient.displayConversation(selectedPatient.getUserId());
                        break;
                    case 2:
                        chatClient.displayConversation(selectedPatient.getUserId());
                        break;
                    case 3:
                        chatting = false;
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            }
        } else {
            System.out.println("Invalid selection.");
        }
    }
    
    // New Doctor function to start a video consultation
   private static void startVideoConsultation(Doctor doctor) {
    System.out.println("\n===== START VIDEO CONSULTATION =====");
    if (doctor.getPatients().isEmpty()) {
        System.out.println("You have no patients assigned.");
        return;
    }
    
    System.out.println("Select a patient for video consultation:");
    for (int i = 0; i < doctor.getPatients().size(); i++) {
        Patient patient = doctor.getPatients().get(i);
        System.out.println((i+1) + ". " + patient.getName() + " (ID: " + patient.getUserId() + ")");
    }
    
    System.out.print("Enter patient number: ");
    int patientIndex = getIntInput() - 1;
    
    if (patientIndex >= 0 && patientIndex < doctor.getPatients().size()) {
        Patient selectedPatient = doctor.getPatients().get(patientIndex);
        
        // Check if there is a valid doctor-patient relationship
        if (!chatServer.validateDoctorPatientRelationship(doctor.getUserId(), selectedPatient.getUserId())) {
            System.out.println("Error: No valid doctor-patient relationship found.");
            return;
        }
        
        // Initiate the video call and get both call ID and meeting link
     // Create ChatClient instance for doctor (sender)
ChatClient chatClient = new ChatClient(doctor.getUserId());

// Correct method call with only the receiver's ID (patient)
Map<String, String> callInfo = chatClient.initiateVideoCall(selectedPatient.getUserId());

// Extract and print call information
String callId = callInfo.get("callId");
String meetingLink = callInfo.get("meetingLink");

System.out.println("Video call initiated with " + selectedPatient.getName());
System.out.println("Call ID: " + callId);
System.out.println("Meeting link: " + meetingLink);
System.out.println("Waiting for patient to join...");

        
        // Store the call information in the system for the patient to access
        chatServer.storeCallInvitation(callId, doctor.getUserId(), selectedPatient.getUserId(), meetingLink);
        
        System.out.print("Press enter to end the call...");
        scanner.nextLine();
        
        chatClient.endVideoCall(callId);
        System.out.println("Video call ended.");
    } else {
        System.out.println("Invalid selection.");
    }
}


    
    // New method to send immediate notification to patient
   private static void sendNotificationToPatient(Doctor doctor) {
    System.out.println("\n===== SEND NOTIFICATION TO PATIENT =====");

    // Initialize notification system if not already initialized
    if (emailNotification == null || smsNotification == null || reminderService == null) {
        initializeNotificationSystem();
    }

    List<Patient> assignedPatients = doctor.getPatients();

    if (assignedPatients == null || assignedPatients.isEmpty()) {
        System.out.println("You have no patients assigned.");
        return;
    }

    // Filter out null patients
    List<Patient> validPatients = assignedPatients.stream()
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

    if (validPatients.isEmpty()) {
        System.out.println("All assigned patients are invalid or missing.");
        return;
    }

    System.out.println("Select a patient to notify:");
    for (int i = 0; i < validPatients.size(); i++) {
        Patient patient = validPatients.get(i);
        System.out.println((i + 1) + ". " + patient.getName() + " (ID: " + patient.getUserId() + ")");
    }

    System.out.print("Enter patient number: ");
    int patientIndex = getIntInput() - 1;

    if (patientIndex < 0 || patientIndex >= validPatients.size()) {
        System.out.println("Invalid patient selection.");
        return;
    }

    Patient selectedPatient = validPatients.get(patientIndex);

    System.out.println("\nSelect notification method:");
    System.out.println("1. Email");
    System.out.println("2. SMS");
    System.out.println("3. Both");
    System.out.print("Select an option: ");

    int notificationMethod = getIntInput();

    System.out.print("Enter notification subject: ");
    String subject = scanner.nextLine();

    System.out.print("Enter notification message: ");
    String message = scanner.nextLine();

    switch (notificationMethod) {
        case 1:
            if (emailNotification.sendNotification(selectedPatient.getContactInfo(), subject, message)) {
                System.out.println("Email notification sent to " + selectedPatient.getName());
            } else {
                System.out.println("Failed to send email notification.");
            }
            break;
        case 2:
            if (smsNotification.sendNotification(selectedPatient.getContactInfo(), subject, message)) {
                System.out.println("SMS notification sent to " + selectedPatient.getName());
            } else {
                System.out.println("Failed to send SMS notification.");
            }
            break;
        case 3:
            boolean emailSent = emailNotification.sendNotification(selectedPatient.getContactInfo(), subject, message);
            boolean smsSent = smsNotification.sendNotification(selectedPatient.getContactInfo(), subject, message);

            if (emailSent && smsSent) {
                System.out.println("Both email and SMS notifications sent to " + selectedPatient.getName());
            } else if (emailSent) {
                System.out.println("Only email notification sent.");
            } else if (smsSent) {
                System.out.println("Only SMS notification sent.");
            } else {
                System.out.println("Failed to send notifications.");
            }
            break;
        default:
            System.out.println("Invalid notification method selected.");
    }
}

    
    // New method to manage patient reminders
    private static void managePatientReminders(Doctor doctor) {
        System.out.println("\n===== MANAGE PATIENT REMINDERS =====");
        if (doctor.getPatients().isEmpty()) {
            System.out.println("You have no patients assigned.");
            return;
        }
        
        System.out.println("Select a patient to manage reminders for:");
        for (int i = 0; i < doctor.getPatients().size(); i++) {
            Patient patient = doctor.getPatients().get(i);
            System.out.println((i+1) + ". " + patient.getName() + " (ID: " + patient.getUserId() + ")");
        }
        
        System.out.print("Enter patient number: ");
        int patientIndex = getIntInput() - 1;
        
        if (patientIndex >= 0 && patientIndex < doctor.getPatients().size()) {
            Patient selectedPatient = doctor.getPatients().get(patientIndex);
            
            boolean managing = true;
            while (managing) {
                System.out.println("\n===== REMINDER MANAGEMENT FOR " + selectedPatient.getName() + " =====");
                System.out.println("1. Schedule Appointment Reminder");
                System.out.println("2. Schedule Medication Reminder");
                System.out.println("3. View Patient's Reminders");
                System.out.println("4. Cancel a Reminder");
                System.out.println("5. Send Immediate Appointment Reminder");
                System.out.println("6. Send Immediate Medication Reminder");
                System.out.println("7. Back to Main Menu");
                System.out.print("Select an option: ");
                
                int choice = getIntInput();
                
                switch (choice) {
                    case 1:
                        scheduleAppointmentReminder(doctor, selectedPatient);
                        break;
                    case 2:
                        scheduleMedicationReminder(doctor, selectedPatient);
                        break;
                    case 3:
                        viewPatientReminders(selectedPatient);
                        break;
                    case 4:
                        cancelPatientReminder(selectedPatient);
                        break;
                    case 5:
                        sendImmediateAppointmentReminder(doctor, selectedPatient);
                        break;
                    case 6:
                        sendImmediateMedicationReminder(doctor, selectedPatient);
                        break;
                    case 7:
                        managing = false;
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            }
        } else {
            System.out.println("Invalid selection.");
        }
    }
    
    private static void scheduleAppointmentReminder(Doctor doctor, Patient patient) {
        System.out.println("\n===== SCHEDULE APPOINTMENT REMINDER =====");
        
        // Show patient's appointments
        List<Appointment> appointments = patient.getAppointments();
        
        if (appointments.isEmpty()) {
            System.out.println("This patient has no scheduled appointments.");
            System.out.println("Would you like to schedule an appointment now? (y/n): ");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("y")) {
                bookAppointment(patient);
                // Refresh appointments list
                appointments = patient.getAppointments();
                if (appointments.isEmpty()) {
                    return; // No appointments created
                }
            } else {
                return;
            }
        }
        
        System.out.println("Select an appointment to set a reminder for:");
        for (int i = 0; i < appointments.size(); i++) {
            Appointment appointment = appointments.get(i);
            System.out.println((i+1) + ". Appointment ID: " + appointment.getAppointmentId() + 
                               " with Dr. " + appointment.getDoctorId() + 
                               " on " + dateFormat.format(appointment.getAppointmentDate()));
        }
        
        System.out.print("Enter appointment number: ");
        int appointmentIndex = getIntInput() - 1;
        
        if (appointmentIndex >= 0 && appointmentIndex < appointments.size()) {
            Appointment selectedAppointment = appointments.get(appointmentIndex);
            
            List<String> reminderIds = reminderService.scheduleAppointmentReminder(patient, selectedAppointment);
            
            if (!reminderIds.isEmpty()) {
                System.out.println("Appointment reminder scheduled successfully!");
                System.out.println("Reminder IDs: " + reminderIds);
            } else {
                System.out.println("Failed to schedule appointment reminder.");
            }
        } else {
            System.out.println("Invalid selection.");
        }
    }
    
  private static void scheduleMedicationReminder(Doctor doctor, Patient patient) {
       System.out.println("\n===== SEND NOTIFICATION TO PATIENT =====");

    // Initialize notification system if not already initialized
    if (emailNotification == null || smsNotification == null || reminderService == null) {
        initializeNotificationSystem();
    }

    List<Patient> assignedPatients = doctor.getPatients();

    if (assignedPatients == null || assignedPatients.isEmpty()) {
        System.out.println("You have no patients assigned.");
        return;
    }
        System.out.println("\n===== SCHEDULE MEDICATION REMINDER =====");
        
        System.out.print("Enter medication name: ");
        String medicationName = scanner.nextLine();
        
        System.out.print("Enter dosage: ");
        String dosage = scanner.nextLine();
        
        System.out.print("Enter date and time for medication (dd/MM/yyyy HH:mm): ");
        String dateTimeStr = scanner.nextLine();
        
        try {
            Date medicationDate = dateFormat.parse(dateTimeStr);
            
            // Convert Java util Date to LocalDateTime
            LocalDateTime medicationDateTime = medicationDate.toInstant()
                                                .atZone(java.time.ZoneId.systemDefault())
                                                .toLocalDateTime();
            
            List<String> reminderIds = reminderService.scheduleMedicationReminder(
                patient, medicationName, dosage, medicationDateTime);
            
            if (!reminderIds.isEmpty()) {
                System.out.println("Medication reminder scheduled successfully!");
                System.out.println("Reminder IDs: " + reminderIds);
            } else {
                System.out.println("Failed to schedule medication reminder.");
            }
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use dd/MM/yyyy HH:mm");
        }
    }
    
    private static void viewPatientReminders(Patient patient) {
        System.out.println("\n===== " + patient.getName() + "'s REMINDERS =====");
        
        List<RemainderService.ReminderTask> reminders = reminderService.getPatientReminders(patient.getUserId());
        
        if (reminders.isEmpty()) {
            System.out.println("No reminders scheduled for this patient.");
            return;
        }
        
        for (int i = 0; i < reminders.size(); i++) {
            RemainderService.ReminderTask reminder = reminders.get(i);
            System.out.println((i+1) + ". " + reminder.toString());
        }
    }
    
    private static void cancelPatientReminder(Patient patient) {
        System.out.println("\n===== CANCEL " + patient.getName() + "'s REMINDER =====");
        
        List<RemainderService.ReminderTask> reminders = reminderService.getPatientReminders(patient.getUserId());
        
        if (reminders.isEmpty()) {
            System.out.println("No reminders scheduled for this patient.");
            return;
        }
        
        System.out.println("Select a reminder to cancel:");
        // We need to track the reminder IDs separately since they're not part of the ReminderTask
        Map<Integer, String> reminderIdMap = new java.util.HashMap<>();
        int index = 1;
        
        for (String reminderId : reminderService.scheduledReminders.keySet()) {
            RemainderService.ReminderTask task = reminderService.scheduledReminders.get(reminderId);
            if (task.getPatientId().equals(patient.getUserId())) {
                System.out.println(index + ". Reminder ID: " + reminderId + " - " + task.toString());
                reminderIdMap.put(index, reminderId);
                index++;
            }
        }
        
        if (reminderIdMap.isEmpty()) {
            System.out.println("No reminders found for this patient.");
            return;
        }
        
        System.out.print("Enter reminder number to cancel: ");
        int reminderIndex = getIntInput();
        
        if (reminderIdMap.containsKey(reminderIndex)) {
            String reminderId = reminderIdMap.get(reminderIndex);
            
            if (reminderService.cancelReminder(reminderId)) {
                System.out.println("Reminder cancelled successfully!");
            } else {
                System.out.println("Failed to cancel reminder.");
            }
        } else {
            System.out.println("Invalid selection.");
        }
    }
    
    private static void sendImmediateAppointmentReminder(Doctor doctor, Patient patient) {
          System.out.println("\n===== SEND REMAINDER BY NOTIFICATION TO PATIENT =====");

    // Initialize notification system if not already initialized
    if (emailNotification == null || smsNotification == null || reminderService == null) {
        initializeNotificationSystem();
    }

    List<Patient> assignedPatients = doctor.getPatients();

    if (assignedPatients == null || assignedPatients.isEmpty()) {
        System.out.println("You have no patients assigned.");
        return;
    }
        System.out.println("\n===== SEND IMMEDIATE APPOINTMENT REMINDER =====");
        
        List<Appointment> appointments = patient.getAppointments();
        
        if (appointments.isEmpty()) {
            System.out.println("This patient has no scheduled appointments.");
            return;
        }
        
        System.out.println("Select an appointment to send an immediate reminder for:");
        for (int i = 0; i < appointments.size(); i++) {
            Appointment appointment = appointments.get(i);
            System.out.println((i+1) + ". Appointment ID: " + appointment.getAppointmentId() + 
                               " with Dr. " + appointment.getDoctorId() + 
                               " on " + dateFormat.format(appointment.getAppointmentDate()));
        }
        
        System.out.print("Enter appointment number: ");
        int appointmentIndex = getIntInput() - 1;
        
        if (appointmentIndex >= 0 && appointmentIndex < appointments.size()) {
            Appointment selectedAppointment = appointments.get(appointmentIndex);
            
            reminderService.sendImmediateAppointmentReminder(patient, selectedAppointment);
            System.out.println("Immediate appointment reminder sent successfully!");
        } else {
            System.out.println("Invalid selection.");
        }
    }
    
    private static void sendImmediateMedicationReminder(Doctor doctor, Patient patient) {
         System.out.println("\n===== SEND NOTIFICATION TO PATIENT =====");

    // Initialize notification system if not already initialized
    if (emailNotification == null || smsNotification == null || reminderService == null) {
        initializeNotificationSystem();
    }

    List<Patient> assignedPatients = doctor.getPatients();

    if (assignedPatients == null || assignedPatients.isEmpty()) {
        System.out.println("You have no patients assigned.");
        return;
    }
        System.out.println("\n===== SEND IMMEDIATE MEDICATION REMINDER =====");
        
        System.out.print("Enter medication name: ");
        String medicationName = scanner.nextLine();
        
        System.out.print("Enter dosage: ");
        String dosage = scanner.nextLine();
        
        reminderService.sendImmediateMedicationReminder(patient, medicationName, dosage);
        System.out.println("Immediate medication reminder sent successfully!");
    }

    
//    private static void displayPatientMenu() {
      

    private static void loginAsPatient() {
                 System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();
        
        User user = admin.getUser(patientId);
        if (user != null && user.getRole().equals("Patient")) {
            currentUser = user;
            System.out.println("Welcome, " + user.getName() + "!");
            // Initialize chat client for patient
            chatClient = new ChatClient(user.getUserId());
        } else {
            System.out.println("Invalid patient ID.");
        }
    }
    
    private static void displayPatientMenu() {
    Patient patient = (Patient) currentUser;
    
    // Initialize notification system if not already initialized
    if (emailNotification == null || smsNotification == null || reminderService == null) {
        initializeNotificationSystem();
    }
    
    System.out.println("\n===== PATIENT MENU =====");
    System.out.println("1. Book Appointment");
    System.out.println("2. View My Appointments");
    System.out.println("3. Enter Vital Signs");
    System.out.println("4. View My Feedback");
    System.out.println("5. Provide Feedback to Doctor");
    System.out.println("6. Use Panic Button");
    System.out.println("7. Chat with Doctor");
    System.out.println("8. Join Video Consultation");
    System.out.println("9. View and Manage Reminders"); // New option
    System.out.println("10. Logout");
    System.out.print("Select an option: ");
    
    int choice = getIntInput();
    
    switch (choice) {
        case 1:
            bookAppointment(patient);
            break;
        case 2:
            patient.viewAppointments();
            break;
        case 3:
            enterVitalSigns(patient);
            break;
        case 4:
            patient.viewFeedback();
            break;
        case 5:
            provideDoctorFeedback(patient);
            break;
        case 6:
            usePanicButton(patient);
            break;
        case 7:
            chatWithDoctor(patient);
            break;
        case 8:
            joinVideoConsultation(patient);
            break;
        case 9:
            managePatientReminders(patient); // New function
            break;
        case 10:
            logout();
            break;
        default:
            System.out.println("Invalid choice. Please try again.");
    }
}

    private static void bookAppointment(Patient patient) {
        System.out.println("\n===== AVAILABLE DOCTORS =====");
        boolean doctorsAvailable = false;
        
        for (User user : admin.getUsers().values()) {
            if (user instanceof Doctor) {
                System.out.println("- " + user.getUserId() + ": " + user.getName());
                doctorsAvailable = true;
            }
        }
        
        if (!doctorsAvailable) {
            System.out.println("No doctors available in the system.");
            return;
        }
        
        System.out.print("Enter doctor ID: ");
        String doctorId = scanner.nextLine();
        
        User doctor = admin.getUser(doctorId);
        if (doctor != null && doctor instanceof Doctor) {
            System.out.print("Enter appointment date (dd/MM/yyyy HH:mm): ");
            String dateStr = scanner.nextLine();
            
            try {
                Date appointmentDate = dateFormat.parse(dateStr);
                
                System.out.print("Enter appointment duration (minutes): ");
                int duration = getIntInput();
                Appointment appointment = appointmentManager.createAppointment(
                    patient.getUserId(), doctorId, appointmentDate, duration
                );
                
                patient.scheduleAppointment(appointment);
                ((Doctor) doctor).scheduleAppointment(appointment);
                
                System.out.println("Appointment scheduled successfully!");
                
            } catch (ParseException e) {
                System.out.println("Invalid date format. Please use dd/MM/yyyy HH:mm");
            }
        } else {
            System.out.println("Doctor not found or invalid ID.");
        }
    }
    
    private static void enterVitalSigns(Patient patient) {
        System.out.println("\n===== ENTER VITAL SIGNS =====");
        
        System.out.print("Heart rate (BPM): ");
        double heartRate = getDoubleInput();
        
        System.out.print("Oxygen level (%): ");
        double oxygenLevel = getDoubleInput();
        
        System.out.print("Blood pressure (systolic): ");
        double systolic = getDoubleInput();
        
        System.out.print("Blood pressure (diastolic): ");
        double diastolic = getDoubleInput();
        
        System.out.print("Temperature (°C): ");
        double temperature = getDoubleInput();
        
        VitalSigns vitalSign = new VitalSigns(
            patient.getUserId(), heartRate, oxygenLevel, systolic, diastolic, temperature
        );
        
        vitalsDatabase.addVitalSign(vitalSign);
        patient.addVitalSign(vitalSign);
        
        System.out.println("Vital signs recorded successfully!");
        
        // Automatically check if vital signs trigger an emergency alert
        System.out.println("Checking vital signs against emergency thresholds...");
        
        // Find the patient's doctor
        Doctor assignedDoctor = null;
        for (User user : admin.getUsers().values()) {
            if (user instanceof Doctor) {
                Doctor doctor = (Doctor) user;
                for (Patient p : doctor.getPatients()) {
                    if (p.getUserId().equals(patient.getUserId())) {
                        assignedDoctor = doctor;
                        break;
                    }
                }
                if (assignedDoctor != null) break;
            }
        }
        
        if (assignedDoctor != null) {
            emergencyAlert.monitorVitalSigns(patient, assignedDoctor);
        } else {
            System.out.println("Warning: No doctor assigned to monitor vital signs.");
        }
    }
    
    private static void provideDoctorFeedback(Patient patient) {
        System.out.print("Enter doctor ID: ");
        String doctorId = scanner.nextLine();
        
        User user = admin.getUser(doctorId);
        if (user != null && user instanceof Doctor) {
            System.out.print("Enter your feedback: ");
            String feedbackText = scanner.nextLine();
            
            FeedBack feedback = new FeedBack(patient.getUserId(), doctorId, feedbackText);
            System.out.println("Feedback submitted: " + feedback);
        } else {
            System.out.println("Doctor not found or invalid ID.");
        }
    }
    
    // Updated Patient function to use panic button with improved OOP
    private static void usePanicButton(Patient patient) {
        System.out.println("\n===== EMERGENCY PANIC BUTTON =====");
        
        // Find patient's doctor
        Doctor assignedDoctor = null;
        for (User user : admin.getUsers().values()) {
            if (user instanceof Doctor) {
                Doctor doctor = (Doctor) user;
                for (Patient p : doctor.getPatients()) {
                    if (p.getUserId().equals(patient.getUserId())) {
                        assignedDoctor = doctor;
                        break;
                    }
                }
                if (assignedDoctor != null) break;
            }
        }
        
        if (assignedDoctor == null) {
            System.out.println("Error: You don't have an assigned doctor. Please contact administration.");
            return;
        }
        
        System.out.println("WARNING: This will send an emergency alert to your doctor.");
        System.out.println("Only use in case of a genuine emergency.");
        System.out.print("Enter brief description of your emergency (or leave blank): ");
        String emergencyDesc = scanner.nextLine();
        
        System.out.print("Are you sure you want to trigger the emergency alert? (y/n): ");
        String confirm = scanner.nextLine();
        
        if (confirm.equalsIgnoreCase("y")) {
            // Using the abstract method from the base class instead of the specific "pressButton" method
            panicButton.triggerAlert(patient, assignedDoctor, emergencyDesc);
        } else {
            System.out.println("Panic button activation cancelled.");
        }
    }
    
    // ===== UTILITY FUNCTIONS =====
    
    private static void logout() {
        currentUser = null;
        System.out.println("You have been logged out.");
    }
    
    private static int getIntInput() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    
    private static double getDoubleInput() {
        try {
            return Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

   private static void chatWithDoctor(Patient patient) {
    System.out.println("\n===== CHAT WITH DOCTOR =====");

    List<Doctor> assignedDoctors = patient.getAssignedDoctors();

    // No assigned doctors yet
    if (assignedDoctors.isEmpty()) {
        System.out.println("You don't have any assigned doctors.");
        System.out.print("Would you like to assign a doctor now? (yes/no): ");
        String input = scanner.nextLine();

        if (input.equalsIgnoreCase("yes")) {
            System.out.print("Enter Doctor ID to assign: ");
            String doctorId = scanner.nextLine();

            User user = chatServer.getUser(doctorId);
            if (user instanceof Doctor) {
                Doctor doctor = (Doctor) user;

                // Create bi-directional link
                patient.assignDoctor(doctor);
                doctor.addPatient(patient);
                System.out.println("Doctor " + doctor.getName() + " assigned successfully.");

                assignedDoctors = patient.getAssignedDoctors(); // refresh list
            } else {
                System.out.println("Doctor not found or invalid ID.");
                return;
            }
        } else {
            return;
        }
    }

    // Show assigned doctors
    System.out.println("Select a doctor to chat with:");
    for (int i = 0; i < assignedDoctors.size(); i++) {
        Doctor doctor = assignedDoctors.get(i);
        System.out.println((i + 1) + ". Dr. " + doctor.getName() + " (ID: " + doctor.getUserId() + ")");
    }

    System.out.print("Enter doctor number: ");
    int doctorIndex = getIntInput() - 1;

    if (doctorIndex >= 0 && doctorIndex < assignedDoctors.size()) {
        Doctor selectedDoctor = assignedDoctors.get(doctorIndex);

        // Validate relationship again for safety
        if (!chatServer.validateDoctorPatientRelationship(selectedDoctor.getUserId(), patient.getUserId())) {
            System.out.println("Error: No valid doctor-patient relationship found.");
            return;
        }

        // Start chat session
        System.out.println("\n===== CHAT WITH DR. " + selectedDoctor.getName() + " =====");
        chatClient.displayConversation(selectedDoctor.getUserId());

        boolean chatting = true;
        while (chatting) {
            System.out.println("\n1. Send message");
            System.out.println("2. Refresh conversation");
            System.out.println("3. End chat session");
            System.out.print("Select an option: ");

            int choice = getIntInput();
           // scanner.nextLine(); // clear newline after int input

            switch (choice) {
                case 1:
                    System.out.print("Enter your message: ");
                    String message = scanner.nextLine();
                    chatClient.sendMessage(selectedDoctor.getUserId(), message);
                    break;
                case 2:
                    chatClient.displayConversation(selectedDoctor.getUserId());
                    break;
                case 3:
                    chatting = false;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    } else {
        System.out.println("Invalid selection.");
    }
}
private static void joinVideoConsultation(Patient patient) {
    System.out.println("\n===== JOIN VIDEO CONSULTATION =====");
    List<Doctor> assignedDoctors = patient.getAssignedDoctors();
    if (assignedDoctors.isEmpty()) {
        System.out.println("You don't have any assigned doctors.");
        System.out.print("Would you like to assign a doctor now? (yes/no): ");
        String input = scanner.nextLine();
        if (input.equalsIgnoreCase("yes")) {
            System.out.print("Enter the Doctor ID to assign: ");
            String doctorId = scanner.nextLine();
            Doctor doctor = (Doctor) chatServer.getUser(doctorId);
            if (doctor != null) {
                patient.assignDoctor(doctor);
                doctor.addPatient(patient);
                chatServer.registerUser(doctor);  // Safe registration
                System.out.println("Doctor " + doctor.getName() + " assigned.");
            } else {
                System.out.println("Doctor not found.");
                return;
            }
        } else {
            return;
        }
    }
    
    // Check for any pending call invitations
   // Create ChatClient instance for the patient
ChatClient chatClient = new ChatClient(patient.getUserId());

// Get pending invitations (no need to pass userId)
List<Map<String, String>> pendingCalls = chatClient.getPendingCallInvitations();

if (pendingCalls.isEmpty()) {
    System.out.println("No pending video consultation invitations found.");
    System.out.println("You can only join video consultations when a doctor initiates them.");
    return;
}

    
    System.out.println("Pending video consultation invitations:");
    for (int i = 0; i < pendingCalls.size(); i++) {
        Map<String, String> callInfo = pendingCalls.get(i);
        String callId = callInfo.get("callId");
        String doctorId = callInfo.get("doctorId");
        String meetingLink = callInfo.get("meetingLink");
        String doctorName = chatServer.getUserName(doctorId);
        
        System.out.println((i + 1) + ". Call from Dr. " + doctorName + " (Call ID: " + callId + ")");
    }
    
    System.out.print("Enter call number to join: ");
    int callIndex = getIntInput() - 1;
    if (callIndex >= 0 && callIndex < pendingCalls.size()) {
        Map<String, String> selectedCall = pendingCalls.get(callIndex);
        String callId = selectedCall.get("callId");
        String meetingLink = selectedCall.get("meetingLink");
        
        System.out.println("Joining video consultation...");
        System.out.println("Meeting link: " + meetingLink);
        System.out.println("Please open this link in your browser to join the video call.");
        
        chatClient.joinVideoCall(callId);
        System.out.println("You have joined the video call.");
        
        System.out.print("Press enter to leave the call...");
        scanner.nextLine();
        
        chatClient.leaveVideoCall(callId);
        System.out.println("You have left the video call.");
    } else {
        System.out.println("Invalid selection.");
    }
}
private static void managePatientReminders(Patient patient) {
    System.out.println("\n===== MANAGE YOUR REMINDERS =====");
    
    boolean managing = true;
    while (managing) {
        System.out.println("1. View Upcoming Reminders");
        System.out.println("2. Respond to Reminders");
        System.out.println("3. Request New Reminder");
        System.out.println("4. Cancel a Reminder");
        System.out.println("5. Back to Main Menu");
        System.out.print("Select an option: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                viewUpcomingReminders(patient);
                break;
            case 2:
                respondToReminders(patient);
                break;
            case 3:
                requestNewReminder(patient);
                break;
            case 4:
                cancelPatientReminder(patient);
                break;
            case 5:
                managing = false;
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }
}

// View upcoming reminders for the patient
private static void viewUpcomingReminders(Patient patient) {
    System.out.println("\n===== YOUR UPCOMING REMINDERS =====");
    
    List<RemainderService.ReminderTask> reminders = reminderService.getPatientReminders(patient.getUserId());
    
    if (reminders.isEmpty()) {
        System.out.println("You have no upcoming reminders.");
        return;
    }
    
    for (int i = 0; i < reminders.size(); i++) {
        RemainderService.ReminderTask reminder = reminders.get(i);
        System.out.println((i+1) + ". " + formatReminderForPatient(reminder));
    }
}

// Format reminder information in a friendly way for patients
private static String formatReminderForPatient(RemainderService.ReminderTask reminder) {
    String reminderType = reminder.getReminderType();
    String target = reminder.getTargetId();
    String time = reminder.getScheduledTime().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    String channel = reminder.getChannelType().toString();
    
    if (reminderType.equals("APPOINTMENT")) {
        return "Appointment (ID: " + target + ") reminder on " + time + " via " + channel;
    } else if (reminderType.equals("MEDICATION")) {
        return "Medication (" + target + ") reminder on " + time + " via " + channel;
    } else {
        return reminderType + " reminder for " + target + " on " + time + " via " + channel;
    }
}

// Respond to reminders (confirm, request reschedule, etc.)
private static void respondToReminders(Patient patient) {
    System.out.println("\n===== RESPOND TO REMINDERS =====");
    
    List<RemainderService.ReminderTask> reminders = reminderService.getPatientReminders(patient.getUserId());
    
    if (reminders.isEmpty()) {
        System.out.println("You have no active reminders to respond to.");
        return;
    }
    
    // We need to track the reminder IDs to handle responses
    Map<Integer, String> reminderIdMap = new HashMap<>();
    int index = 1;
    
    for (String reminderId : reminderService.scheduledReminders.keySet()) {
        RemainderService.ReminderTask task = reminderService.scheduledReminders.get(reminderId);
        if (task.getPatientId().equals(patient.getUserId())) {
            System.out.println(index + ". " + formatReminderForPatient(task));
            reminderIdMap.put(index, reminderId);
            index++;
        }
    }
    
    if (reminderIdMap.isEmpty()) {
        System.out.println("No reminders found that need response.");
        return;
    }
    
    System.out.print("Enter reminder number to respond to (0 to cancel): ");
    int reminderIndex = getIntInput();
    
    if (reminderIndex == 0) {
        return;
    }
    
    if (reminderIdMap.containsKey(reminderIndex)) {
        String reminderId = reminderIdMap.get(reminderIndex);
        RemainderService.ReminderTask task = reminderService.scheduledReminders.get(reminderId);
        
        System.out.println("\nHow would you like to respond?");
        System.out.println("1. Confirm (I'll be there / I'll take my medication)");
        System.out.println("2. Request reschedule");
        System.out.println("3. Request more information");
        System.out.print("Enter your response: ");
        
        int responseType = getIntInput();
        String responseMessage = "";
        
        switch (responseType) {
            case 1:
                responseMessage = "CONFIRMED: Patient has acknowledged this reminder.";
                // In a real system, we might mark this in a database
                System.out.println("Reminder confirmed.");
                break;
            case 2:
                System.out.print("Enter preferred date/time (dd/MM/yyyy HH:mm): ");
                String newTime = scanner.nextLine();
                responseMessage = "RESCHEDULE REQUEST: Patient has requested rescheduling to " + newTime;
                System.out.println("Reschedule request sent to your doctor.");
                break;
            case 3:
                System.out.print("What additional information do you need? ");
                String question = scanner.nextLine();
                responseMessage = "INFO REQUEST: " + question;
                System.out.println("Information request sent to your doctor.");
                break;
            default:
                System.out.println("Invalid response type.");
                return;
        }
        
        // Send response back to the doctor
        if (task.getReminderType().equals("APPOINTMENT")) {
            // Find the doctor associated with this appointment
            String appointmentId = task.getTargetId();
            // Find the doctor for this appointment
            Doctor appointmentDoctor = findDoctorForAppointment(appointmentId);
            
            if (appointmentDoctor != null) {
                // Send notification to doctor about patient's response
                for (Notifiable channel : reminderService.getNotificationChannels()) {
                    channel.sendNotification(
                        appointmentDoctor.getContactInfo(),
                        "Patient Response - " + patient.getName(),
                        responseMessage
                    );
                }
                System.out.println("Your response has been sent to Dr. " + appointmentDoctor.getName());
            } else {
                System.out.println("Could not find the doctor for this appointment.");
            }
        } else {
            // For medication or other reminders, find assigned doctor
            Doctor assignedDoctor = findAssignedDoctor(patient);
            if (assignedDoctor != null) {
                for (Notifiable channel : reminderService.getNotificationChannels()) {
                    channel.sendNotification(
                        assignedDoctor.getContactInfo(),
                        "Patient Response - " + patient.getName(),
                        responseMessage
                    );
                }
                System.out.println("Your response has been sent to Dr. " + assignedDoctor.getName());
            } else {
                System.out.println("Could not find your assigned doctor.");
            }
        }
    } else {
        System.out.println("Invalid selection.");
    }
}

// Request a new reminder
private static void requestNewReminder(Patient patient) {
    System.out.println("\n===== REQUEST NEW REMINDER =====");
    System.out.println("1. Appointment Reminder");
    System.out.println("2. Medication Reminder");
    System.out.print("Select reminder type: ");
    
    int reminderType = getIntInput();
    
    // Find the patient's doctor
    Doctor assignedDoctor = findAssignedDoctor(patient);
    
    if (assignedDoctor == null) {
        System.out.println("You don't have an assigned doctor. Please contact administration.");
        return;
    }
    
    switch (reminderType) {
        case 1:
            requestAppointmentReminder(patient, assignedDoctor);
            break;
        case 2:
            requestMedicationReminder(patient, assignedDoctor);
            break;
        default:
            System.out.println("Invalid reminder type.");
    }
}

// Request a new appointment reminder
private static void requestAppointmentReminder(Patient patient, Doctor doctor) {
    List<Appointment> appointments = patient.getAppointments();
    
    if (appointments.isEmpty()) {
        System.out.println("You have no scheduled appointments.");
        return;
    }
    
    System.out.println("Select an appointment to request a reminder for:");
    for (int i = 0; i < appointments.size(); i++) {
        Appointment appointment = appointments.get(i);
        System.out.println((i+1) + ". Appointment ID: " + appointment.getAppointmentId() + 
                           " with Dr. " + appointment.getDoctorId() + 
                           " on " + dateFormat.format(appointment.getAppointmentDate()));
    }
    
    System.out.print("Enter appointment number: ");
    int appointmentIndex = getIntInput() - 1;
    
    if (appointmentIndex >= 0 && appointmentIndex < appointments.size()) {
        Appointment selectedAppointment = appointments.get(appointmentIndex);
        
        // Send request to doctor
        String message = "Patient " + patient.getName() + " is requesting a reminder for " +
                        "appointment ID: " + selectedAppointment.getAppointmentId() + 
                        " scheduled for " + dateFormat.format(selectedAppointment.getAppointmentDate());
        
        for (Notifiable channel : reminderService.getNotificationChannels()) {
            channel.sendNotification(
                doctor.getContactInfo(),
                "Reminder Request from Patient",
                message
            );
        }
        
        System.out.println("Reminder request sent to Dr. " + doctor.getName());
    } else {
        System.out.println("Invalid selection.");
    }
}

// Request a new medication reminder
private static void requestMedicationReminder(Patient patient, Doctor doctor) {
    System.out.print("Enter medication name: ");
    String medicationName = scanner.nextLine();
    
    System.out.print("Enter dosage: ");
    String dosage = scanner.nextLine();
    
    System.out.print("Enter preferred reminder time (dd/MM/yyyy HH:mm): ");
    String timeStr = scanner.nextLine();
    
    // Send request to doctor
    String message = "Patient " + patient.getName() + " is requesting a medication reminder for " +
                    medicationName + " (" + dosage + ") at " + timeStr;
    
    for (Notifiable channel : reminderService.getNotificationChannels()) {
        channel.sendNotification(
            doctor.getContactInfo(),
            "Medication Reminder Request from Patient",
            message
        );
    }
    
    System.out.println("Medication reminder request sent to Dr. " + doctor.getName());
}

// Helper method to cancel a patient's reminder
//private static void cancelPatientReminder(Patient patient) {
//    System.out.println("\n===== CANCEL REMINDER =====");
//    
//    List<RemainderService.ReminderTask> reminders = reminderService.getPatientReminders(patient.getUserId());
//    
//    if (reminders.isEmpty()) {
//        System.out.println("You have no reminders to cancel.");
//        return;
//    }
//    
//    // We need to track the reminder IDs to handle responses
//    Map<Integer, String> reminderIdMap = new HashMap<>();
//    int index = 1;
//    
//    for (String reminderId : reminderService.scheduledReminders.keySet()) {
//        RemainderService.ReminderTask task = reminderService.scheduledReminders.get(reminderId);
//        if (task.getPatientId().equals(patient.getUserId())) {
//            System.out.println(index + ". " + formatReminderForPatient(task));
//            reminderIdMap.put(index, reminderId);
//            index++;
//        }
//    }
//    
//    if (reminderIdMap.isEmpty()) {
//        System.out.println("No reminders found that can be cancelled.");
//        return;
//    }
//    
//    System.out.print("Enter reminder number to cancel (0 to go back): ");
//    int reminderIndex = getIntInput();
//    
//    if (reminderIndex == 0) {
//        return;
//    }
//    
//    if (reminderIdMap.containsKey(reminderIndex)) {
//        String reminderId = reminderIdMap.get(reminderIndex);
//        RemainderService.ReminderTask task = reminderService.scheduledReminders.get(reminderId);
//        
//        // Find the doctor to notify about cancellation
//        Doctor doctorToNotify = null;
//        if (task.getReminderType().equals("APPOINTMENT")) {
//            doctorToNotify = findDoctorForAppointment(task.getTargetId());
//        } else {
//            doctorToNotify = findAssignedDoctor(patient);
//        }
//        
//        // Cancel the reminder
//        if (reminderService.cancelReminder(reminderId)) {
//            System.out.println("Reminder cancelled successfully!");
//            
//            // Notify the doctor if found
//            if (doctorToNotify != null) {
//                String reminderDesc = task.getReminderType().equals("APPOINTMENT") ? 
//                    "appointment (ID: " + task.getTargetId() + ")" : 
//                    "medication (" + task.getTargetId() + ")";
//                
//                String message = "Patient " + patient.getName() + " has cancelled the reminder for " + 
//                                reminderDesc + " scheduled for " + 
//                                task.getScheduledTime().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
//                
//                for (Notifiable channel : reminderService.getNotificationChannels()) {
//                    channel.sendNotification(
//                        doctorToNotify.getContactInfo(),
//                        "Reminder Cancellation",
//                        message
//                    );
//                }
//                
//                System.out.println("Dr. " + doctorToNotify.getName() + " has been notified of the cancellation.");
//            }
//        } else {
//            System.out.println("Failed to cancel reminder.");
//        }
//    } else {
//        System.out.println("Invalid selection.");
//    }
//}

// Helper method to find assigned doctor for a patient
private static Doctor findAssignedDoctor(Patient patient) {
    // Find the patient's doctor
    for (User user : admin.getUsers().values()) {
        if (user instanceof Doctor) {
            Doctor doctor = (Doctor) user;
            for (Patient p : doctor.getPatients()) {
                if (p != null && p.getUserId().equals(patient.getUserId())) {
                    return doctor;
                }
            }
        }
    }
    return null;
}

// Helper method to find doctor for a specific appointment
private static Doctor findDoctorForAppointment(String appointmentId) {
    for (User user : admin.getUsers().values()) {
        if (user instanceof Doctor) {
            Doctor doctor = (Doctor) user;
            for (Appointment appointment : doctor.getAppointments()) {
                if (appointment.getAppointmentId().equals(appointmentId)) {
                    return doctor;
                }
            }
        }
    }
    return null;
}
}
