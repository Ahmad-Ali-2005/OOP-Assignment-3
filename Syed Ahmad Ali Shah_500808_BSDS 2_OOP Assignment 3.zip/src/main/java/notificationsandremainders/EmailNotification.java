package notificationsandremainders;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Implements Notifiable for sending emails
 * @author Student
 */
public class EmailNotification implements Notifiable {
    // Encapsulation - private fields
    private String senderEmail;
    private Map<String, ScheduledNotification> scheduledEmails;
    
    /**
     * Constructor for EmailNotification
     * @param senderEmail The email address notifications will be sent from
     */
    public EmailNotification(String senderEmail) {
        this.senderEmail = senderEmail;
        this.scheduledEmails = new HashMap<>();
    }
    
   
    @Override
    public boolean sendNotification(String recipientId, String subject, String message) {
        // In a real implementation, this would use JavaMail API or similar to send emails
        System.out.println("Sending EMAIL to: " + recipientId);
        System.out.println("From: " + senderEmail);
        System.out.println("Subject: " + subject);
        System.out.println("Message: " + message);
        System.out.println("Email sent successfully");
        return true;
    }
    
   
    @Override
    public String scheduleNotification(String recipientId, String subject, String message, int delayInMinutes) {
        String notificationId = "EMAIL-" + System.currentTimeMillis();
        LocalDateTime scheduledTime = LocalDateTime.now().plusMinutes(delayInMinutes);
        
        ScheduledNotification notification = new ScheduledNotification(
            recipientId, subject, message, scheduledTime
        );
        
        scheduledEmails.put(notificationId, notification);
        
        System.out.println("Email scheduled to be sent to " + recipientId + " at " + scheduledTime);
        return notificationId;
    }
    
   
    @Override
    public boolean cancelNotification(String notificationId) {
        if (scheduledEmails.containsKey(notificationId)) {
            scheduledEmails.remove(notificationId);
            System.out.println("Email notification " + notificationId + " cancelled");
            return true;
        }
        System.out.println("Email notification " + notificationId + " not found");
        return false;
    }
    
  
    @Override
    public NotificationType getType() {
        return NotificationType.EMAIL;
    }
    
 
    public void processScheduledEmails() {
        LocalDateTime now = LocalDateTime.now();
        Map<String, ScheduledNotification> pendingEmails = new HashMap<>(scheduledEmails);
        
        for (Map.Entry<String, ScheduledNotification> entry : pendingEmails.entrySet()) {
            String notificationId = entry.getKey();
            ScheduledNotification notification = entry.getValue();
            
            if (notification.getScheduledTime().isBefore(now) || notification.getScheduledTime().isEqual(now)) {
                sendNotification(
                    notification.getRecipientId(),
                    notification.getSubject(),
                    notification.getMessage()
                );
                scheduledEmails.remove(notificationId);
            }
        }
    }
    
   
    private class ScheduledNotification {
        private String recipientId;
        private String subject;
        private String message;
        private LocalDateTime scheduledTime;
        
        public ScheduledNotification(String recipientId, String subject, String message, LocalDateTime scheduledTime) {
            this.recipientId = recipientId;
            this.subject = subject;
            this.message = message;
            this.scheduledTime = scheduledTime;
        }
        
        public String getRecipientId() {
            return recipientId;
        }
        
        public String getSubject() {
            return subject;
        }
        
        public String getMessage() {
            return message;
        }
        
        public LocalDateTime getScheduledTime() {
            return scheduledTime;
        }
    }
}